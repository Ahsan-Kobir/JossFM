package com.akapps.jossfm4u;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.net.Uri;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ChildEventListener;
import android.view.View;
import com.bumptech.glide.Glide;
import android.graphics.Typeface;

public class HomeActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String img1 = "";
	private String img2 = "";
	private String img3 = "";
	private String img4 = "";
	
	private ArrayList<HashMap<String, Object>> lst = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linearm;
	private LinearLayout linear3;
	private LinearLayout linear1;
	private LinearLayout linear4;
	private LinearLayout menu_layout;
	private ImageView imageview1;
	private LinearLayout linear6;
	private LinearLayout linear8;
	private ImageView stream_status_icon;
	private LinearLayout linear7;
	private ImageView play_pause;
	private TextView textview2;
	private TextView status;
	private TextView program;
	private TextView updates;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private ImageView upcoming;
	private TextView textview4;
	private ImageView query;
	private TextView textview5;
	private ImageView about;
	private TextView textview6;
	
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private Intent in = new Intent();
	private DatabaseReference db = _firebase.getReference("datas");
	private ChildEventListener _db_child_listener;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linearm = (LinearLayout) findViewById(R.id.linearm);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		menu_layout = (LinearLayout) findViewById(R.id.menu_layout);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		stream_status_icon = (ImageView) findViewById(R.id.stream_status_icon);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		play_pause = (ImageView) findViewById(R.id.play_pause);
		textview2 = (TextView) findViewById(R.id.textview2);
		status = (TextView) findViewById(R.id.status);
		program = (TextView) findViewById(R.id.program);
		updates = (TextView) findViewById(R.id.updates);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		upcoming = (ImageView) findViewById(R.id.upcoming);
		textview4 = (TextView) findViewById(R.id.textview4);
		query = (ImageView) findViewById(R.id.query);
		textview5 = (TextView) findViewById(R.id.textview5);
		about = (ImageView) findViewById(R.id.about);
		textview6 = (TextView) findViewById(R.id.textview6);
		net = new RequestNetwork(this);
		
		upcoming.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), EventsActivity.class);
				startActivity(in);
			}
		});
		
		query.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), QueryActivity.class);
				startActivity(in);
			}
		});
		
		about.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				in.setClass(getApplicationContext(), AboutActivity.class);
				startActivity(in);
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_db_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db.addChildEventListener(_db_child_listener);
	}
	private void initializeLogic() {
		_startSlide();
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/captcha.ttf"), 1);
		status.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/captcha.ttf"), 1);
		program.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/captcha.ttf"), 1);
		updates.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/captcha.ttf"), 1);
		db.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lst = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lst.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				if (lst.get((int)0).get("updates").toString().equals("hidden")) {
					updates.setVisibility(View.GONE);
				}
				else {
					updates.setText(lst.get((int)0).get("updates").toString());
				}
				program.setText(lst.get((int)0).get("program").toString());
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	private void _startSlide () {
		
		img1 = "/sdcard/pic.png";
		img2 = "/sdcard/pic2.png";
		img3 = "/sdcard/pic.png";
		img4 = "/sdcard/pic2.png";
		
		img1 = "https://manysolutions.com/media/deals/deal/1520951988big30.1536563451.jpg";
		img2 = "https://manysolutions.com/media/deals/deal/1520951858Blog_Banner.1536563451.jpg";
		img3 = "https://manysolutions.com/media/deals/deal/many-solutions-1562585627manysolutions-remarkable-tablet.jpg";
		img4 = "https://manysolutions.com/media/deals/deal/many-solutions-1554980423airlock.jpg";
		
		View v1 = (View) getLayoutInflater().inflate(R.layout.bnr1, null);
		
		final ImageView image1 = (ImageView) v1.findViewById(R.id.imageview1);
		
		Glide.with(getApplicationContext()).load(Uri.parse(img1)).into(image1);
		
		
		View v2 = (View) getLayoutInflater().inflate(R.layout.bnr2, null);
		
		final ImageView image2 = (ImageView) v2.findViewById(R.id.imageview1);
		
		Glide.with(getApplicationContext()).load(Uri.parse(img2)).into(image2);
		
		
		View v3 = (View) getLayoutInflater().inflate(R.layout.bnr3, null);
		
		final ImageView image3 = (ImageView) v3.findViewById(R.id.imageview1);
		
		Glide.with(getApplicationContext()).load(Uri.parse(img3)).into(image3);
		
		
		View v4 = (View) getLayoutInflater().inflate(R.layout.bnr4, null);
		
		final ImageView image4 = (ImageView) v4.findViewById(R.id.imageview1);
		
		Glide.with(getApplicationContext()).load(Uri.parse(img4)).into(image4);
		
		
		ViewGroup.LayoutParams lp =new ViewGroup.LayoutParams(getDisplayWidthPixels(), LinearLayout.LayoutParams.WRAP_CONTENT);
		ViewFlipper vfl = new ViewFlipper(this);
		
		vfl.addView(v1, 0, lp);
		vfl.addView(v2, 1, lp);
		vfl.addView(v3, 2, lp);
		vfl.addView(v4, 3, lp);
		
		
		vfl.setAutoStart(true);
		linear1.addView(vfl);
	}
	public static Animation inFromRight(long ms){
		Animation right = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, +1.0f, Animation.RELATIVE_TO_PARENT, 0.0f,Animation.RELATIVE_TO_PARENT, 0.0f, Animation.RELATIVE_TO_PARENT, 0.0f);
		
		right.setDuration(ms);
		return right;
	}
	
	
	public static Animation outToLeft(long ms){
		Animation left = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0.0f, Animation.RELATIVE_TO_PARENT, -1.0f,Animation.RELATIVE_TO_PARENT, 0.0f, Animation.RELATIVE_TO_PARENT, 0.0f);
		
		left.setDuration(ms);
		return left;
		
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
