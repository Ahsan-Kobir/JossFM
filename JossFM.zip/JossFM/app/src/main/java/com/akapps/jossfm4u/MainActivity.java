package com.akapps.jossfm4u;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.content.Intent;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;

	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		new Timer().schedule(new TimerTask(){
			public void run() {
				runOnUiThread(new Runnable() {
					public void run() {
						//startActivity(new Intent(MainActivity.this, HomeActivity.class));
						net.startRequestNetwork(RequestNetworkController.GET, "http://clients3.google.com/generate_204", "", _net_request_listener);
					}
				});
			}
		}, 2000);
	}

	private void initialize(Bundle _savedInstanceState) {

		net = new RequestNetwork(this);

		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _response = _param2;
				startActivity(new Intent(MainActivity.this, HomeActivity.class));
				finish();
			}

			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;

				Toast.makeText(MainActivity.this, "No Internet", Toast.LENGTH_SHORT).show();
				}
		};
	}

}